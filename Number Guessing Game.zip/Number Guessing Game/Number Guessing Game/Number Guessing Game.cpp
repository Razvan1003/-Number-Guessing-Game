﻿#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int random() {
    
    srand(static_cast<unsigned int>(time(0)));
    return rand() % 100 + 1;
}

void ghicire(int& guess_num,int variabila) {
   

    while (guess_num != variabila) {
        cout << "Enter your guess: ";
        cin >> guess_num;

        if (guess_num > variabila) {
            cout << "Too high!Try again\n";
        }
        else if (guess_num < variabila) {
            cout << "Too low!Try again\n";
        }
        else {
            cout << "Conratulations! You guessed secret number!\n";
        }
    }

}


int main()
{
    cout << "I have chosen a number between 1 and 100\n";

    int variabila = random();
    int guess_num = 0;

    ghicire(guess_num, variabila);

   
   
}

